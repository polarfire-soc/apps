#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <poll.h>

uint8_t dma_complete = 0;

int uioFd_0,d=0;
int uioFd_1;
volatile uint32_t *ddr_mem,*dma_mem,*lsram_mem;

#define UIO_0_DEVICE    "/dev/uio0"
#define UIO_1_DEVICE    "/dev/uio1"

#define MMAP_SIZE     0x10000

int main(int argc, char* argvp[])
{
	int retCode = 0;
	char d1;	
	uint32_t memread[5]={0xAA,0x77,0xbb,0xcc,0x05};
	uint32_t val = 0;
	volatile uint32_t i=0 ;
	uint32_t var1 =0;
	int32_t intInfo;
	ssize_t readSize;
	uint32_t reenable=1,pending=0,temp1;
 
	// Open uio_0 device
	uioFd_0 = open(UIO_0_DEVICE, O_RDWR);
	if(uioFd_0 < 0)
	{
		fprintf(stderr, "Cannot open %s: %s\n", UIO_0_DEVICE, strerror(errno));
		return -1;
	}

	uioFd_1 = open(UIO_1_DEVICE, O_RDWR);
	if(uioFd_0 < 0)
	{
		fprintf(stderr, "Cannot open %s: %s\n", UIO_0_DEVICE, strerror(errno));
		return -1;
	}

	dma_mem = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED, uioFd_1, 0*getpagesize());
			if(dma_mem == MAP_FAILED){
				fprintf(stderr, "Cannot mmap: %s\n", strerror(errno));
				close(uioFd_0);
				return -1;
			}
	
	while(1){
		printf("\n\t # Choose one of  the following options: \n\t Enter 1 to access LSRAM \n\t Enter 2 to write data from LSRAM to LPDD4 via DMA access  \n\t Enter 3 to Exit\n");
		scanf("%c%*c",&d1);
		if(d1=='3'){
			break;
		}else if(d1=='1')
			{
				lsram_mem = mmap(NULL, MMAP_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, uioFd_0, 0*getpagesize());
				if(lsram_mem == MAP_FAILED){
					fprintf(stderr, "Cannot mmap: %s\n", strerror(errno));
					close(uioFd_0);
					return -1;
				}
				printf("\nAccessing 64KB of  LSRAM memory at address 0x61000000\n");
				for(i=0;i<(MMAP_SIZE/4);i++)
				{
					*(lsram_mem+i)=i;
				 	val=*(lsram_mem+i);
                 		if(val !=i)
						{
                    		printf("\n\n\r ***** LSRAM memory test Failed***** \n\r");
                        	break;
                    	}
                   		else if(i%100 == 0)
                    	{
                    		printf(".");
                    	}
			}
			if(i == (MMAP_SIZE/4))
				printf("\n\n\n**** LSRAM memory test Passed with incremental pattern*****\n");
		}
		else if(d1=='2') 
		{
			lsram_mem = mmap(NULL, MMAP_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, uioFd_0, 0*getpagesize());
			if(lsram_mem == MAP_FAILED){
				fprintf(stderr, "Cannot mmap: %s\n", strerror(errno));
				close(uioFd_0);
				return -1;
			}
			
			ddr_mem = mmap(NULL, MMAP_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, uioFd_0, 1*getpagesize());
			if(ddr_mem == MAP_FAILED){
				fprintf(stderr, "Cannot mmap: %s\n", strerror(errno));
				close(uioFd_0);
				return -1;
			}
			printf("\nConfiguring dma controller at  0x60020000\n");
        	/* Initialize LSRAM */
			for(i=0;i<64;i=i+1) {
				*(lsram_mem +i) = 0x12345678+i;
                var1 = *(lsram_mem+i);
				if(var1 == 0x12345678+i){
					 printf(".");
				}else {
                    	printf("\n\n\r ***** LSRAM memory test Failed***** \n\r");
                        break;
                    }
               }
			printf("\nwritting data into LSRAM completed\n");
            temp1 = *(dma_mem);   //version control register
	      	printf("\n\rversion control Reg = 0x%x \n\r", temp1);

            *(dma_mem + (0x14/4))  = 0x00000001;  //Interrupt mask
            printf("\n\rMask reg  = 0x%x\n\r", * (dma_mem + (0x14/4)) );

            *(dma_mem + (0x64/4))  = 0x00000020;  //byte count
            printf("\n\rByte count   = 0x%x\n\r", * (dma_mem + (0x64/4)) );

            *(dma_mem + (0x68/4))  = 0x61000000;  // Source address
            printf("\n\rSource Address  = 0x%x\n\r",   * (dma_mem + (0x68/4)) );

            *(dma_mem + (0x6C/4))  = 0xC0000000;  //destination address
            printf("\n\rDestination  Address LPDDR4  = 0x%x\n\r",* (dma_mem + (0x6C/4)) );

            *(dma_mem + (0x60/4))  = 0x0000F005;  //data ready,descriptor valid,sop,dop,chain
            printf("\n\rDesriptor config   = 0x%x\n\r", * (dma_mem + (0x60/4)) );

            * (dma_mem + (0x04/4))  = 0x00000001;  //start operation register
            printf("\n\rWaitting for DMA to finish\n\r" );

	    while(1){
		   if((*(dma_mem + (0x10/4)) & 0x01) == 0x01){
		       *(dma_mem + (0x18/4))=0x00000001;
	          	dma_complete = 1;
		   	break;
		   }
	       }
			   
		printf("\n\n\n**** DMA transfer completed from LSRAM to LPDDR4 *****\n");
		printf("\n\n\n**** verifing the memory  *****\n");
		while(1){
                 printf("\n\n\r *****Reading LPDDR4  memory***** \n\r");
                 for(i=0;i<8 ;i++){
                     val = *(ddr_mem+i);
                     var1 = *(lsram_mem+i);
                     if(val==var1){
                          printf(".");
                     }else{
                          printf("\nLPDDR4 data verification failed\n");
                          break;
                     }
                 }
		if(i == 8)
                 printf("\nLPDDR4 data verification Passed\n");
                 break;
       		}
	}else {
			printf("Enter either 1, 2, and 3\n");
		}
	munmap((void*)lsram_mem, MMAP_SIZE);
	munmap((void*)ddr_mem, MMAP_SIZE);
	

	}	
	munmap((void*)dma_mem, MMAP_SIZE);
	close(uioFd_0);
	close(uioFd_1);
	return retCode;
}

