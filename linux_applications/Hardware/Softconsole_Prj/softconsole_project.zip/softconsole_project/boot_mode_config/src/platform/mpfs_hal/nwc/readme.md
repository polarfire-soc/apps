# North West Corner directory

This directory contains code related to the MSS and particuar the north west 
corner of the MSS.

* Clocks
* DDR 
* SGMII
* MSSIO configuration

