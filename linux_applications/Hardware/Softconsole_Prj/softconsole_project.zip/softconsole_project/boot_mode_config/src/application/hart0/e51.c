/*******************************************************************************
 * Copyright 2019-2020 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-Identifier: MIT
 *
 * MPFS HAL Embedded Software example
 *
 */
/*******************************************************************************
 *
 * Code running on E51
 *
 */

#include <stdio.h>


/* Main function for the HART0(E51 processor).
 * Application code running on HART0 is placed here.
 * Just added dummy application for boot mode configurations
 */

void e51(void)
{


	while(1)
	{

	}



}



