contains user configuration of the drivers.
drivers config should follow the following format:
platform/config/drivers/<same folder name as driver folder>/<driver name>_sw_cfg.h
e.g
platform/config/drivers/ddr/ddr_sw_cfg.h