contains user configuration of the platform
e.g. division of memory between harts etc.