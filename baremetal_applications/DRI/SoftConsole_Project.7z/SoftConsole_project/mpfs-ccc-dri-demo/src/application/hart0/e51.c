/*******************************************************************************
 * Copyright 2019-2020 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-Identifier: MIT
 *
 * MPFS HAL Embedded Software example
 *
 */
/*******************************************************************************
 *
 * Code running on E51
 *
 */

#include <stdio.h>
#include <string.h>
#include "mpfs_hal/mss_hal.h"

#include "drivers/mss_mmuart/mss_uart.h"

#include "mpfs_hal/common/mss_hart_ints.h"


static volatile uint32_t count_sw_ints_h0 = 0U;

mss_uart_instance_t *g_uart= &g_mss_uart0_lo ;

uint64_t uart_lock;
void init_uart(void)
{
	//Initialize UART
	/* Turn on UART0 clock */
	SYSREG->SUBBLK_CLOCK_CR |= (SUBBLK_CLOCK_CR_MMUART0_MASK |\
			SUBBLK_CLOCK_CR_MMUART1_MASK |\
			SUBBLK_CLOCK_CR_MMUART2_MASK |\
			SUBBLK_CLOCK_CR_MMUART3_MASK |\
			SUBBLK_CLOCK_CR_MMUART4_MASK);
	SYSREG->SUBBLK_CLOCK_CR |=0xFFFFFFFF;
	/* Remove soft reset */
	SYSREG->SOFT_RESET_CR   &= ~(SUBBLK_CLOCK_CR_MMUART0_MASK |\
			SUBBLK_CLOCK_CR_MMUART1_MASK |\
			SUBBLK_CLOCK_CR_MMUART2_MASK |\
			SUBBLK_CLOCK_CR_MMUART3_MASK |\
			SUBBLK_CLOCK_CR_MMUART4_MASK);
	/*This mutex is used to serialize accesses to UART0 when all harts want to
	 * TX/RX on UART0. This mutex is shared across all harts.*/
	mss_init_mutex((uint64_t)&uart_lock);

	MSS_UART_init( &g_mss_uart0_lo,
			MSS_UART_115200_BAUD,
			MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);

}

/* Main function for the HART0(E51 processor).
 * Application code running on HART0 is placed here.
 */

void e51(void)
{

	init_uart();
	raise_soft_interrupt(1);
	while(1)
	{

	}


}

/* HART0 Software interrupt handler */
void Software_h0_IRQHandler(void)
{
	uint64_t hart_id = read_csr(mhartid);
	count_sw_ints_h0++;
}



