/*******************************************************************************
 * Copyright 2019-2020 Microchip FPGA Embedded Systems Solution.
 *
 * SPDX-License-Identifier: MIT
 *
 * MPFS HAL Embedded Software example
 *
 */
/*******************************************************************************
 *
 * Code running on U54 first hart
 *
 */
#include <stdio.h>
#include <string.h>
#include "mpfs_hal/mss_hal.h"
#include "drivers/mss_mmuart/mss_uart.h"
#include "mpfs_hal/common/mss_plic.h"
#include "mpfs_hal/common/mss_h2f.h"
#include "hal/hw_reg_access.h"

volatile uint64_t count_sw_ints_h1 = 0;
extern uint64_t uart_lock;
PLL_TypeDef *CCC_SCB_SW_PLL = ((PLL_TypeDef *) 0x48400000);
volatile uint32_t timer_out=0x000000FFU;
/*==============================================================================
  Private functions.
 */

/*******************************************************************************
 * Instruction message. This message will be transmitted over the UART to
 * HyperTerminal when the program starts.
 ******************************************************************************/

const uint8_t g_default_msg[] =
"\r\n\r\n\r\n\
Press 1 to change the CCC PLL OUT0 and OUT1 Frequencies\r\n\
Press 2 to change the CCC PLL OUT2 and OUT3 Frequencies\r\n\
Press 3 to change the REF_DIV divider value \r\n\
";

uint8_t data_buffer [1024];

static void clear_data_buffer(void)
{
	uint32_t idx=0;

	while( idx < 1024 )
	{
		data_buffer[idx++] = 0x00;
	}
}


/* Main function for the HART1(U54_1 processor).
 * Application code running on HART1 is placed here
 *
 * The HART1 goes into WFI. HART0 brings it out of WFI when it raises the first
 * Software interrupt to this HART
 */
void u54_1(void)
{


	uint8_t rx_buff[1], tx_buff[1];
	uint8_t rx_size = 0,tx_size=0;
	clear_data_buffer();

	set_csr(mie, MIP_MSIP);

	/*Put this hart into WFI.*/
	do
	{
		__asm("wfi");
	}while(0 == (read_csr(mip) & MIP_MSIP));

	/*The hart is out of WFI, clear the SW interrupt. Hear onwards Application
	 * can enable and use any interrupts as required*/
	clear_soft_interrupt();

    SYSREG->SOFT_RESET_CR &= 0x00U;
    SYSREG->SUBBLK_CLOCK_CR = 0xffffffff;

	__enable_irq();


	MSS_UART_polled_tx_string(&g_mss_uart0_lo, "\n\r **** PolarFireSoC CCC DRI demo ****\n\r CCC Registers configuration: \n\r ");

	uprint32(&g_mss_uart0_lo, "\n\r CCC PLL_REF_FB register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_REF_FB );
	uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_0_1 register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_DIV_0_1);
	uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_2_3 register:\n\r  = \r",  CCC_SCB_SW_PLL->PLL_DIV_2_3 );
	uprint32(&g_mss_uart0_lo, "\n\r CCC SSCG_reg2  register: \n\r  = \r",  MSS_SCB_MSS_PLL->SSCG_REG_2 );

	mss_take_mutex((uint64_t)&uart_lock);
	MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_default_msg);
	mss_release_mutex((uint64_t)&uart_lock);



	while (1)
	{
		mss_take_mutex((uint64_t)&uart_lock);
		rx_size = MSS_UART_get_rx(&g_mss_uart0_lo, rx_buff, sizeof(rx_buff));
		mss_release_mutex((uint64_t)&uart_lock);

		if (rx_size > 0)
		{
			switch(rx_buff[0])
			{
			case '0':
				break;
            case '1':
					MSS_UART_polled_tx_string(&g_mss_uart0_lo, "\n\r PLL DIV_0_1 Register configuration changed for new PLL OUT0 and OUT1 divider values--- \n\r \
						   \r\n OUT0 clock changed to 240MHz and OUT1 clock changed to 100MHz \n\r ");

            	CCC_SCB_SW_PLL->SOFT_RESET    |= (1<<8);
            	CCC_SCB_SW_PLL->PLL_CTRL      &= ~(1<<0);
            	CCC_SCB_SW_PLL->PLL_DIV_0_1    = (uint32_t)  0x0C000500;
            	CCC_SCB_SW_PLL->PLL_CTRL    |= (1<<0);
            	CCC_SCB_SW_PLL->SOFT_RESET      &= ~(1<<8);

        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLL_REF_FB register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_REF_FB );
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_0_1 register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_DIV_0_1);
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_2_3 register:\n\r  = \r",  CCC_SCB_SW_PLL->PLL_DIV_2_3 );

	    		mss_take_mutex((uint64_t)&uart_lock);
	    		MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_default_msg );
	    		mss_release_mutex((uint64_t)&uart_lock);

                break;

            case '2':

				MSS_UART_polled_tx_string(&g_mss_uart0_lo,"\n\r PLL DIV_2_3 Register configuration changed with new PLL OUT2 and OUT3 divider \n\r");
            	MSS_UART_polled_tx_string(&g_mss_uart0_lo, "\n\r OUT2 clock changed to 100 MHz and OUT3 clock changed to 75MHz \n\r");

            	CCC_SCB_SW_PLL->SOFT_RESET    |= (1<<8);
            	CCC_SCB_SW_PLL->PLL_CTRL      &= ~(1<<0);
            	CCC_SCB_SW_PLL->PLL_DIV_2_3    = (uint32_t)  0x10000C00;
            	CCC_SCB_SW_PLL->PLL_CTRL    |= (1<<0);
            	CCC_SCB_SW_PLL->SOFT_RESET      &= ~(1<<8);
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLL_REF_FB register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_REF_FB );
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_0_1 register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_DIV_0_1);
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_2_3 register:\n\r  = \r",  CCC_SCB_SW_PLL->PLL_DIV_2_3 );

	    		mss_take_mutex((uint64_t)&uart_lock);
	    		MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_default_msg );
	    		mss_release_mutex((uint64_t)&uart_lock);

                break;

            case '3':

                MSS_UART_polled_tx_string(&g_mss_uart0_lo, "\n\r Register configuration of PLL_REF_FB changed to new divider 4 \n\r");
				MSS_UART_polled_tx_string(&g_mss_uart0_lo, "\n\r OUT0 clock changed to 25MHz, OUT1 clock changed to 18.75MHz, OUT2 clock changed to 12.5MHz and OUT4 clock changed to 6.25MHz \n\r");

            	CCC_SCB_SW_PLL->SOFT_RESET    |= (1<<8);
            	CCC_SCB_SW_PLL->PLL_CTRL      &= ~(1<<0);
            	CCC_SCB_SW_PLL->PLL_REF_FB     = (uint32_t) 0x00000400;
            	CCC_SCB_SW_PLL->PLL_CTRL      |= (1<<0);
            	CCC_SCB_SW_PLL->SOFT_RESET      &= ~(1<<8);

               while((CCC_SCB_SW_PLL->PLL_CTRL & PLL_CTRL_LOCK_BIT) == 0U)
               {
                   if (timer_out != 0U)
                   {
                       timer_out--;
                   }
                   else
                   {
                   }
               }

        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLL_REF_FB register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_REF_FB );
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_0_1 register: \n\r  = \r", CCC_SCB_SW_PLL->PLL_DIV_0_1);
        		uprint32(&g_mss_uart0_lo, "\n\r CCC PLLdiv_2_3 register:\n\r  = \r",  CCC_SCB_SW_PLL->PLL_DIV_2_3 );

	    		mss_take_mutex((uint64_t)&uart_lock);
	    		MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_default_msg );
	    		mss_release_mutex((uint64_t)&uart_lock);
            	break;

			default:
	    		mss_take_mutex((uint64_t)&uart_lock);
	    		MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_default_msg );
	    		mss_release_mutex((uint64_t)&uart_lock);
				break;
			}
		}

	}

	/* never return */
}


/* HART1 Software interrupt handler */
void Software_h1_IRQHandler(void)
{
	uint64_t hart_id = read_csr(mhartid);
	count_sw_ints_h1++;
}


static void dumpbyte(mss_uart_instance_t * uart, uint8_t b)
{
    const char hexchrs[] = { '0','1','2','3','4','5','6','7','8','9','A','B',\
            'C','D','E','F' };
    MSS_UART_polled_tx(uart, &hexchrs[b >> 4u] , 1);
    MSS_UART_polled_tx(uart, &hexchrs[b & 0x0fu] , 1);
}


/**
 *
 * @param uart
 * @param msg
 * @param d
 */
__attribute__((weak))\
        void uprint32(mss_uart_instance_t * uart, const char* msg, uint32_t d)
{
    MSS_UART_polled_tx_string(uart, msg);
    for (unsigned i=0; i < 4; i++)
    {
        dumpbyte(uart, (d >> (8*(3-i))) & 0xffu);
    }
}
