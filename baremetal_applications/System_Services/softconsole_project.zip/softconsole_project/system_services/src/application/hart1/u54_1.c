/*******************************************************************************
 * Copyright 2019-2020 Microchip FPGA Embedded Systems Solution.
 *
 * SPDX-License-Identifier: MIT
 *
 * MPFS HAL Embedded Software example
 *
 */
/*******************************************************************************
 *
 * Code running on U54 first hart
 *
 */
#include <stdio.h>
#include <string.h>
#include "mpfs_hal/mss_hal.h"
#include "drivers/mss_mmuart/mss_uart.h"

#include "drivers/mss_sys_services/mss_sys_services.h"
#include "helper.h"
#include "mpfs_hal/mss_ints.h"

volatile uint32_t count_sw_ints_h1 = 0U;

extern uint64_t uart_lock;

/*****************************************************************************
 * MSS_SYS_MAILBOX_DATA_OFFSET
 * Mailbox data offset for all system services.
 */
#define MSS_SYS_MAILBOX_DATA_OFFSET                           0u

/*==============================================================================
  Private functions.
 */
static void execute_puf_emulation_service(void);
static void execute_digital_signature_service(void);




/*******************************************************************************
 * Instruction message. This message will be transmitted over the UART to
 * HyperTerminal when the program starts.
 ******************************************************************************/
const uint8_t g_greeting_msg[] =
		"\r\n **** PolarFireSoC system services Example ****\n\r\
Notes: Return data from System controller is displayed byte-wise with LSB first\n\r\
       Input data is provided LSB first. Each ASCII character is one Nibble of data\n\n\r\
Select Service:\n\r\n\
Device and Design Information Services:\n\r\n\
1. Read Device Serial Number \r\n\
2. Read Device User-code \r\n\
3. Read Device Design-info \r\n\
4. Read Device Certificate \r\n\
5. Read Digest \r\n\
6. Query Security \r\n\
7. Read Debug Information \n\r\n\
Data Security Services:\n\r\n\
8. Digital Signature \r\n\
9. PUF Emulation \r\n\
a. Nonce\n\r";


const uint8_t g_separator[] =
		"\r\n----------------------------------------------------------------------\r\n";

static void display_greeting(void);

uint8_t data_buffer [1024];
uint8_t nonce_data[32];
uint8_t input_text[128] = {0x00};



static void clear_data_buffer(void)
{
	uint32_t idx=0;

	while( idx < 1024 )
	{
		data_buffer[idx++] = 0x00;
	}
}


/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_greeting_msg);
}





void execute_serial_number_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Device serial number: ");
	status = MSS_SYS_get_serial_number(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_SERIAL_NUMBER_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Service read device serial number failed.\n\r");

	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

void execute_usercode_service(void)
{
	uint8_t status,code[4];

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"32bit USERCODE/Silicon signature (MSB first): ");
	status = MSS_SYS_get_user_code(data_buffer, 0);
	code[0] = data_buffer[3];
	code[1] = data_buffer[2];
	code[2] = data_buffer[1];
	code[3] = data_buffer[0];
	if(MSS_SYS_SUCCESS == status)
	{
		display_output(code, MSS_SYS_USERCODE_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"USERCODE Service failed.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

void execute_designinfo_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Design ID:");
	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
	status = MSS_SYS_get_design_info(data_buffer, 0);
	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, 32);
		MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Design Version: ");
		display_output((data_buffer + 32), 2);
		MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Design Back-Level: ");
		display_output((data_buffer + 34), 2);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"DesignInfo Service failed.\n\r");

	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

void execute_devicecertificate_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Device Certificate:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
	status = MSS_SYS_get_device_certificate(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_DEVICE_CERTIFICATE_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Device Certificate Service failed.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");

		if(MSS_SYS_DCF_INVALID_SIGNATURE == status)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)
					"Error - Invalid certificate signature");
		}

		if(MSS_SYS_DCF_DEVICE_MISMATCH == status)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Error - Device Mismatch");
		}

		if(MSS_SYS_DCF_SYSTEM_ERROR == status)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Error - System Error");
		}
	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

void execute_readdigest_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Read Digest:\n\r");
	status = MSS_SYS_read_digest(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_READ_DIGEST_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Read Digest Service failed.\n\r");

	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}


void execute_querysecurity_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Security locks: ");
	status = MSS_SYS_query_security(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_QUERY_SECURITY_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Query Security Service failed.\n\r");

	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

void execute_readdebuginfo_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Debug info:\n\r");

	status = MSS_SYS_read_debug_info(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_READ_DEBUG_INFO_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Read Debug Info Service failed.\n\r");

	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);

}

void execute_nonce_service(void)
{
	uint8_t status;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Generated Nonce:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");
	status = MSS_SYS_nonce_service(data_buffer, 0);

	if(MSS_SYS_SUCCESS == status)
	{
		display_output(data_buffer, MSS_SYS_NONCE_SERVICE_RESP_LEN);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Nonce Service  failed.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"\n\r");

		if(MSS_SYS_NONCE_PUK_FETCH_ERROR == status)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Error fetching PUK");
		}
		else if(MSS_SYS_NONCE_SEED_GEN_ERROR == status)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo, (const uint8_t*)"Error generating seed");
		}
	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}


/* Main function for the HART1(U54_1 processor).
 * Application code running on HART1 is placed here
 *
 * The HART1 goes into WFI. HART0 brings it out of WFI when it raises the first
 * Software interrupt to this HART
 */
void u54_1(void)
{


	uint8_t rx_buff[1];
	uint8_t rx_size = 0;
	clear_data_buffer();
	/*Clear pending software interrupt in case there was any.
      Enable only the software interrupt so that the E51 core can bring this
      core out of WFI by raising a software interrupt.*/
	clear_soft_interrupt();
	set_csr(mie, MIP_MSIP);

	/*Put this hart into WFI.*/
	do
	{
		__asm("wfi");
	}while(0 == (read_csr(mip) & MIP_MSIP));

	/*The hart is out of WFI, clear the SW interrupt. Hear onwards Application
	 * can enable and use any interrupts as required*/
	clear_soft_interrupt();


	__enable_irq();



	//init_gpio_timer();
	mss_take_mutex((uint64_t)&uart_lock);
	MSS_UART_polled_tx_string (&g_mss_uart0_lo, g_greeting_msg);
	mss_release_mutex((uint64_t)&uart_lock);


	while (1)
	{
		mss_take_mutex((uint64_t)&uart_lock);
		rx_size = MSS_UART_get_rx(&g_mss_uart0_lo, rx_buff, sizeof(rx_buff));
		mss_release_mutex((uint64_t)&uart_lock);

		if (rx_size > 0)
		{
			MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
			switch(rx_buff[0])
			{
			case '1':
				execute_serial_number_service();
				break;

			case '2':
				execute_usercode_service();
				break;

			case '3':
				execute_designinfo_service();
				break;

			case '4':
				execute_devicecertificate_service();
				break;

			case '5':
				execute_readdigest_service();
				break;

			case '6':
				execute_querysecurity_service();
				break;

			case '7':
				execute_readdebuginfo_service();
				break;

			case '8':
				execute_digital_signature_service();
				break;

			case '9':
				execute_puf_emulation_service();
				break;

			case 'a':
				execute_nonce_service();
				break;

			default:
				display_greeting();
				break;
			}
		}


	}

	/* never return */
}


/*==============================================================================
  Demonstrates  PUF emulation service.
 */
static void execute_puf_emulation_service(void)
{
	uint8_t challenge[16] = {0x00};
	uint8_t op_type[2] = {0x00};
	uint8_t response[32] = {0x00};
	uint8_t status = 0;
	uint32_t index = 0;

	status = MSS_SYS_nonce_service(data_buffer, 0);
	if(status == MSS_SYS_SUCCESS)
	{
		op_type[0] = data_buffer[0]; /* Read challenge optype from Nonce 1st byte.*/

		for(index = 0;index<16;index++)
		{
			challenge[index] = data_buffer[index]; /* Read challenge bytes from Nonce initial 16 bytes.*/
		}
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"The challenge OPTYPE range(0x0 to 0xFF): ");
		display_output(&op_type[0] , 1);
		///MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\r16 byte challenge: ");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		display_output(&challenge[0] , 16);
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\r");
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)" PUF emulation service failed.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	}


	status = MSS_SYS_puf_emulation_service(challenge,op_type[0],response, 0);

	/* Display status information on UART terminal. */
	if(status == MSS_SYS_SUCCESS)
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"PUF emulation service successful.Generated Response:\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");

		display_output(&response[0], 32);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\r\n Service puf emulation failed.");
	}
	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);
}

static void execute_digital_signature_service(void)
{
	uint8_t hash[MSS_SYS_DIGITAL_SIGNATURE_HASH_DATA_LEN] = {0x00};
	uint8_t response[152] = {0x00};
	uint8_t status = 0;
	uint32_t index = 0;

	MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"Digital Signature service:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"48 byte hash value:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	/* genearte hash value using Nonce service.*/
	status = MSS_SYS_nonce_service(data_buffer, 0);
	if(status == MSS_SYS_SUCCESS)
	{
		for(index = 0;index<MSS_SYS_NONCE_SERVICE_RESP_LEN;index++)
		{
			hash[index] = data_buffer[index];
		}
		for(;index<MSS_SYS_DIGITAL_SIGNATURE_HASH_DATA_LEN;index++)
		{
			hash[index] = data_buffer[index- MSS_SYS_NONCE_SERVICE_RESP_LEN];
		}
		display_output(&hash[0], MSS_SYS_DIGITAL_SIGNATURE_HASH_DATA_LEN);
	}
	else
	{
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\rDigital Signature service failed.");
	}
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\rRaw format:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	status = MSS_SYS_digital_signature_service(hash,
			MSS_SYS_DIGITAL_SIGNATURE_RAW_FORMAT_REQUEST_CMD,
			response,
			0u);

	if(status == MSS_SYS_SUCCESS)
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Digital Signature service successful.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Output Digital Signature - Raw format:\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		display_output(&response[0], 96);
	}
	else
	{
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\rDigital Signature service failed.");
	}
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\rDER format:\n\r");
	//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	status = MSS_SYS_digital_signature_service(hash,
			MSS_SYS_DIGITAL_SIGNATURE_DER_FORMAT_REQUEST_CMD,
			response,
			0u);

	if(status == MSS_SYS_SUCCESS)
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\rDigital Signature service successful.");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");

		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"\n\rOutput Digital Signature - DER format:\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");

		display_output(&response[0], 104);
	}
	else
	{
		MSS_UART_polled_tx_string(&g_mss_uart0_lo,
				(const uint8_t*)"Digital Signature service failed.\n\r");
		//MSS_UART_polled_tx_string(&g_mss_uart0_lo,(const uint8_t*)"\n\r");
	}

	MSS_UART_polled_tx_string(&g_mss_uart0_lo, g_separator);

}




/* HART1 Software interrupt handler */
void Software_h1_IRQHandler(void)
{
	uint64_t hart_id = read_csr(mhartid);
	count_sw_ints_h1++;
}


